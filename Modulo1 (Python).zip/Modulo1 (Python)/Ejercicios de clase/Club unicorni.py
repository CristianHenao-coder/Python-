
# Validación de edad
edad= int(input(" Cuantos años tienes : " ))

# condicionales para validar su edad y en que categoria entra 
if edad >= 18: 

    PASE= input("Tiene pase Dorado: ")
    PASE=PASE.lower()

    if PASE=='no' or PASE=="not":
       
        if edad >25:
             
             print("Usted no puede entrar por que es mayor a 25") 
        else:
              print("Usted si puede entrar porque esta en el rango 18 a 25")



    elif PASE == "si" or PASE== "yes":
        print ("usted tiene pase")
elif edad< 18:
        print ("usted no puede entrar por ser menor de 18;)")







