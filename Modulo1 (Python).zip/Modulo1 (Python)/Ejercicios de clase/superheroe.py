# opcion 2 tren descarilado 


print("El héroe decide hackear el sistema de control del tren desde una terminal remota.")

primeraDecision = int(input("¿Qué desea intentar hackear primero?\n1. Reiniciar los frenos magnéticos.\n2. Estabilizar la levitación del tren.\n"))

if primeraDecision == 1:
    print("El héroe intenta reiniciar los frenos magnéticos...")

    segundaDecision = int(input("Pero detecta una señal de interferencia cercana.\n¿Quiere:\n1. Intentar igual el reinicio a pesar del riesgo.\n2. Buscar y desactivar la fuente de interferencia primero.\n"))

    if segundaDecision == 1:
        print("El sistema falla debido a la interferencia. Los frenos no se activan y el tren sigue acelerando. El héroe debe decidir:")
        terceraDecision = int(input("1. Saltar al tren para intentar frenarlo manualmente.\n2. Enviar una alerta a los pasajeros para evacuar.\n"))

        if terceraDecision == 1:
            print("El héroe se lanza sobre el tren y logra activar manualmente un freno de emergencia.\nEl tren se detiene, pero el impacto es mortal para él. Se convierte en leyenda.")
        elif terceraDecision == 2:
            print("Los pasajeros evacúan con éxito, pero el tren descarrila y explota.\nMueren varios ingenieros que iban en la cabina. El héroe es culpado por no haber intervenido directamente.")

    elif segundaDecision == 2:
        print("El héroe localiza la interferencia y la desactiva. Reinicia los frenos con éxito.\nEl tren se detiene a tiempo. Todos sobreviven y el héroe es celebrado como un genio técnico.")

elif primeraDecision == 2:
    print("El héroe decide estabilizar la levitación del tren.")

    segundaDecision = int(input("Para estabilizar la levitación debe elegir entre:\n1. Reforzar el campo electromagnético desde el sistema base.\n2. Redirigir energía de otros sistemas secundarios.\n"))

    if segundaDecision == 1:
        print("La señal es muy débil y toma tiempo. El tren logra mantenerse en el aire por poco.")
        terceraDecision = int(input("¿Qué hace ahora?\n1. Intentar el reinicio de frenos rápidamente.\n2. Coordinar un aterrizaje de emergencia usando la levitación.\n"))

        if terceraDecision == 1:
            print("El héroe logra reiniciar los frenos justo antes de que colapse el sistema.\nEl tren se detiene y todos sobreviven, aunque el héroe queda con secuelas neurológicas por el esfuerzo.")
        elif terceraDecision == 2:
            print("El aterrizaje de emergencia falla. El tren se estrella y mueren decenas de pasajeros, incluido un grupo escolar.\nEl héroe sobrevive, pero cae en una profunda depresión.")

    elif segundaDecision == 2:
        print("El héroe redirige energía y estabiliza la levitación, pero las comunicaciones se cortan.\nCorre a advertir a los pasajeros.")
        terceraDecision = int(input("1. Intentar evacuar a todos rápidamente.\n2. Sacrificarse quedándose en la terminal para mantener el sistema manualmente.\n"))

        if terceraDecision == 1:
            print("La evacuación es caótica y muchos no logran salir. El sistema falla sin mantenimiento constante y el tren se desploma.")
        elif terceraDecision == 2:
            print("El héroe permanece conectado al sistema, manteniéndolo estable manualmente.\nMuere en la explosión, pero todos los pasajeros sobreviven. Su nombre es grabado en una placa conmemorativa.")