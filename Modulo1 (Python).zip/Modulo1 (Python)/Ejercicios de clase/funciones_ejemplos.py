

def pedirnum ():
    numero1 = int(input("Escribe un numero "))
    numero2 = int(input("Escribe un numero "))
    return numero1, numero2

def sumadenumeros ():
    numero1, numero2 = pedirnum()
    return numero1 + numero2


print(sumadenumeros())


print ("vamos hacer otra papi")

print(sumadenumeros())