
Readme Evaluation:

Menu:
We have a menu that allows us to have different options from 1 to 7 so our customers can choose the one they need. Each option corresponds to a case (the options we can choose):

1. Add products to inventory: You can add the product name, its price, and the available quantity.

2. View products in inventory: Here we can see the added and existing products in this list, easily searching for them by name.

3. Print all products: With this option, we can see in detail all the products we have in our list, knowing both the name of the searched product and its price and corresponding quantity.

4. Update product prices: If you have a product and its value changes, with this option, we can update the new price without having to delete it, simply by modifying its price. 5. Delete products from inventory: Here we can delete a product that is no longer available by choosing option 5. This will allow us to delete the product simply by entering its name.

6. Calculate total inventory value: This option allows us to add the product value to the available quantities, obtaining the total for all products.

7. Exit: If we want to exit the application and complete queries or actions in our menu, we can easily do so with option 7.

Methods:

1. Lower: Allows each piece of data added to a variable to be written in lowercase.

2. Add: Allows us to add data to a list.

Functions: This is a set of instructions that lead us to a result.

1. Update_produc= This function allows us to add the name, price, and quantity of the product we are recording.
Title: This is the name of our product.
Price: This is the individual price of our product. Quantity: How many units of this product do I have?
2. Search_product= This function is used to search for a product in our list, check if it exists, and what data it contains.
It then prints all the stored data for the product we are searching for.
3. Print_product = This function allows us to print all the data on our list in an organized manner, showing its name, price, and quantity.
4. Delete_product = We can delete a piece of data from our list that we no longer want to keep. We search for it by name and, after executing it correctly, we notify the customer that the deletion was successful.

5. Product_quantity = This function is used to update data. In this case, it allows us to change the product's price by updating it to the new price and saving it.

6. Total = With this function, we can see the total for each product and multiply the price by its corresponding quantity, adding another value at the end that corresponds to the sum of all the product totals.