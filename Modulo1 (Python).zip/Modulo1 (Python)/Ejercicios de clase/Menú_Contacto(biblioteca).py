
print("\n\033[1mBienvenidos")


contacto = {"lucas": 3177171890,"marta": 3215847585}



def agregar(): 
    nombre=input("¿cual es tu nombre?:  ")
    celular=input("Numero de celular: ")
    contacto[nombre]= celular


    
def mostrar():
    print("Estos son todos los contactos :")
    for clave, valor in contacto.items(): 
        print(f"{clave}: {valor}")



def buscar():
    nombre=input("Escribe el nombre a buscar: ").lower()
    if nombre in contacto:  
        print (nombre,contacto[nombre])

def eliminar():
    nombreelim= input("Escriba el nombre a eliminar")
    if nombreelim in contacto:
        del contacto[nombreelim]
        print("Usted elimino los datos de ",nombreelim)

    

while True:
    try:
        print("\033[1m\033[32m\n>>>> MENÚ <<<<\n \033[0mElige una de las opciones:\n")
        print( "1. Agregar un nuevo contacto\n"
        "2. Mostrar todos los contactos\n" \
        "3. Buscar un contacto por su nombre\n"
        "4. Eliminar dato\n")

        opcion= int(input("Escribe tu opción: "))
    
        match opcion:
            case 1:
                agregar()
            case 2:
                mostrar()
            case 3:
                buscar()

            case 4:  
                eliminar()
            case _:
                print("papi dejalo sano")
                break
                
    except ValueError:
        print("no seas loca solo numero de los que estan ")



