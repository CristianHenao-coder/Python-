

estudiantes= {}


# Agregar un nuevo estudiante (nombre, edad, calificación).
def agregar():

    nombre= input("Escribe tu Nombre: ")
    edad= int(input("Escribe tu edad: "))
    calificaciones= float(input(" Escribe tu nota"))
    estudiantes[nombre]= {"edad": edad,"calificaciones":calificaciones}
    print ("Tu informacion a sido guardad.")

def modificar():
    nombremod= input("Escriba el nombre que desea eliminar: ")
    if nombremod in estudiantes:
        estudiantes[nombremod]["calificaciones"] = int(input("Modifique la nota: "))


def mostrar():
    print (estudiantes)
  

def eliminar():
    nombreelimina= input("Escriba el nombre para eliminar los datos: ")
    if nombreelimina in estudiantes:
        del estudiantes[nombreelimina]
        print("Usted elimino a" , nombreelimina)


while True:

    print ("\n\033[33m\033[1m >>>> MENÚ <<<< \033[0m\n")
    print (" Elige una de las Opciones:\n" \
    "1. Agregar un nuevo estudiante\n" \
    "2. Modificar la calificación\n" \
    "3. Mostrar la información\n" \
    "4. Eliminar un estudiante por su nombre.\n")

    opcion=int(input("Escriba tu opción: "))

    match opcion:
        case 1:
            agregar()
            
        case 2:
            modificar()
        case 3: 
            mostrar()

        case 4:
            eliminar()




















































    print(".l. <-- Lo que me gusta a mí, Cristian Henao P")