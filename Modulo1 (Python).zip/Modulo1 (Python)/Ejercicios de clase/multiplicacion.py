def multiplicar(a,b):
    resultado = a*b
    return resultado

numero1 = 2
numero2 = 1
multiplicacion = multiplicar(numero1, numero2)
print(multiplicacion)