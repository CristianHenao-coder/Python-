
# list of all products within a dictionary

inventory = [
    {"title": "sauce", "price": 2000, "quantity": 5},
    {"title": "tomato", "price": 700, "quantity": 3},
    {"title": "onion", "price": 500, "quantity": 5},
    {"title": "meat", "price": 10000, "quantity": 10},
    {"title": "avocado", "price": 5000, "quantity": 5}]


# Add products to the list with their name, price, and quantity.
# We create conditions so that the price and quantity values ​​are integers and are greater than 0. Otherwise, we print an error. We do not break the loop until a correct value is added.

def update_produc():

    while True: 
        
        try:
            title= input("Enter the name from product: ").lower()
            price= int(input("Enter the price: "))
            if price  > 0:
                quantity= int(input("Enter quantity of product to add: "))
                if quantity > 0:

                    print("Data added successfully")  
                    inventory.append({"title": title, "price": price,  "quantity": quantity})
                    break
                        
                        
                    
                else:
                        print("ERROR: the quantity must greater than 0. Try again")   
                    

                    
            else:
                print("ERROR: The quantity must greater than 0. Try again")
        except ValueError:
            print("Write in correct number ")

#We create a function to search for a product, asking the customer for the name of the product they want to search for.
#We print all the data from our list.
def search_product():
    namesearch= input("Enter name from product to search: ").lower()
    for x in inventory:
        if namesearch == x["title"]:
            print(f"{x['title']}  price: {x['price']} quantity: {x['quantity']}")
            
            break
    else:
        print("Not found")

#here we print all the data we have in the list

def print_product():
    for x in inventory:
     print (f"{x["title"]}  price: {x["price"]} quantity: {x["quantity"]}")


#we change the value of the product by searching for it by name

def quantity_product():
    searchname= input ("Enter the name from product than want to update: ").lower()
    while True:
        try:
            for x in inventory:
                if x ["title"] == searchname:

                    newprice = int(input("Write your new price: "))
                    if newprice >0:
                        x["price"] = newprice
                        print("Update price")
                                      
                    else:
                        print("Add a number greath that 0")
            
        except ValueError:
            print("ERROR: Add a correct value number ")
        break

#we eliminate a product that we search for by name

def remove_product():

    nameremove = input("Write the name from product than you want remove: ").lower()

    for x in inventory:
        if x ["title"] == nameremove:
            inventory.remove(x)
            print (" Product Remove")
            break
    else:
        print("Product doesn't exist")   

#We create a mathematical operation to be able to multiply the prices with the quantity and then we print the entire sum of the numbers

def total():
    total= 0
    
    for x in inventory:
        total = x["price"] * x["quantity"]

        print (f"Product:" , x["title"] , "its price is: ", x["price"] , "quantity is:" ,x["quantity"] , "and your total is: " ,total)
        
    print (f"Your total values of all products is:" , (sum(x['price'] * x['quantity'] for x in inventory)))






#We create a menu of options so that the person can choose the option they need

while True:

    print("\033[34m\n \033[01m >>> MENÚ <<< \033[0m\n" \
    "1. Add product to the inventory\n" \
    "2. Consult products in inventory\n" \
    "3. Print every the products\n"
    "4. Update price of products\n" \
    "5. Remove products from inventory\n" \
    "6. Calculate the total value from inventory\n" \
    "7. Exit\n")
    
    option= input("Write an option: ")

    match option:
        case "1":
            update_produc()
        case "2":
            search_product()
        case "3":
            print_product()

        case "4":
            quantity_product()
        case "5":
            remove_product()
        case "6":
            total()
        case "7":
            print("Godbye....")
            break