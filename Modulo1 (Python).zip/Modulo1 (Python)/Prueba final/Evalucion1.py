

# 1. permitir al usuario agregar productos con atributos como
# nombre, precio y cantidad disponibles

# 2. buscar un producto por su nombre y mostrar sus
# detalles (nombre, precio, cantidad).

# 3. modificar el precio de un producto específico en el
# inventario.

# 4. permitir la eliminación de un producto que ya no está
# disponible.

# 5. multiplicar el precio por la cantidad de cada producto
# y mostrar el total acumulado.

inventory = [
    {"title": "salsa", "price": 2000, "quantity": 5},
    {"title": "tomate", "price": 700, "quantity": 3},
    {"title": "cebolla", "price": 500, "quantity": 5},
    {"title": "carne", "price": 10000, "quantity": 10},
    {"title": "aguacate", "price": 5000, "quantity": 5}]


def update_produc():

    while True: 
        
        try:
            title= input("Ingrese el nombre del Producto: ").lower()
            price= int(input("Ingresa el precio: "))
            if price  > 0:
                quantity= int(input("Ingresa la cantidad de productos agregar: "))
                if quantity > 0:

                    print("Datos agregados correctamente")  
                    inventory.append({"title": title, "price": price,  "quantity": quantity})
                    break
                        
                        
                    
                else:
                        print("ERROR: La cantidad debe ser mayor a 0. Intenta de nuevo.")   
                    

                    
            else:
                print("ERROR: La cantidad debe ser mayor a 0. Intenta de nuevo.")
        except ValueError:
            print("Escriba un numero valido")
            

        

def search_product():
    namesearch= input("Ingrese nombre del producto a buscar: ").lower()

    for x in inventory:
        if namesearch == x["title"]:
            print(f"{x['title']}  price: {x['price']} quantity: {x['quantity']}")
            
            break
    else:
        print("No encontrado")


def print_product():
    for x in inventory:
     print (f"{x["title"]}  price: {x["price"]} quantity: {x["quantity"]}")



def quantity_product():
    searchname= input ("Ingrese el Nombre del proucto que desea actualizar: ").lower()

    if searchname in inventory:

        while True:
            try:
                for x in inventory:
                    if x ["title"] == searchname:

                        newprice = int(input("Escriba su nuevo precio: "))
                        if newprice >0:
                            x["price"] = newprice
                            print("Precio actualizado")
                                        
                        else:
                            print("Ingrese un numero mayor a 0")
                
            except ValueError:
                print("ERROR: Ingrese un valor numerico correcto")
            break
    else:
        print("No existe ese producto")        
    
def remove_product():

    
    respuesta= input("Esta seguro de que quiere eliminar (eliga si/ no): ").lower()
    si = "si"
    if respuesta is si:
        print("Listo eliminaremos el producto")
        nameremove = input("Escriba el nombre del producto que desea eliminar: ").lower()
        
        for x in inventory:
            if x ["title"] == nameremove:
                    inventory.remove(x)
                    print (" Producto Eliminado")
                      
            else:
                print("Producto no existe")     
    # else: 
    #         print("No eliminaste ninguna producto")  
        


def total():
    total= 0
    
    for x in inventory:
        total = x["price"] * x["quantity"]

        print (f"Producto:" , x["title"] , "su precio es: ", x["price"] , "cantidad es:" ,x["quantity"] , "y su total es: " ,total)
        
    print (f"Su valor total de todos los productos es:" , (sum(x['price'] * x['quantity'] for x in inventory)))




while True:

    print("\033[34m\n \033[01m >>> MENÚ <<< \033[0m\n" \
    "1. Añadir productos al inventario\n" \
    "2. Consultar productos en inventario\n" \
    "3. Imprimir todos los productos\n"
    "4. Actualizar precios de productos\n" \
    "5. Eliminar productos del inventario\n" \
    "6. Calcular el valor total del inventario\n" \
    "7. salir\n")
    
    option= input("Escribe una opción: ")

    match option:
        case "1":
            update_produc()
        case "2":
            search_product()
        case "3":
            print_product()

        case "4":
            quantity_product()
        case "5":
            remove_product()
        case "6":
            total()
        case "7":
            print("Hasta pronto....")
            break