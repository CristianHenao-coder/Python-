# Realizar la Facturacion de nuestros clientes 

nombre=(input("Bienvenido, Escriba Nombre de Usuario "))   #Datos del cliente
              
Nproducto= input( "ingrese Nombre del producto : ") 

Precioprod=int(input(" Precio del Producto "))

while True:
    Canprodu=int(input("Cuantos Productos va a Comprar? "))
    if Canprodu > 0:
        break  # Si el número es mayor a 0, sale del ciclo 
    else:
        print("ERROR: La cantidad debe ser mayor a 0. Intenta de nuevo.")
        print("ERROR: Debes ingresar un número válido. Intenta de nuevo.")

PrecioFinal=int(Canprodu * Precioprod)
if Canprodu >= 3 and Canprodu < 7: 
    print("Tienes un Descuento del 30 porciento")
    Preciodescuento= PrecioFinal *(30/100) 
    print(" Tu Descuento es de: " , Preciodescuento) 
    PrecioFinal2= PrecioFinal - Preciodescuento 
    print(" Tu Precio final es de: " , PrecioFinal2) 
    print("Gracias por tu Compra" , nombre)

elif Canprodu >= 7:
    print(" tienes un descuento del 50% ")
    Preciodescuento= PrecioFinal *(50/100)
    print(" Tu Descuento es de: " , Preciodescuento) 
    PrecioFinal2= PrecioFinal - Preciodescuento 
    print(" Tu Precio final es de: " , PrecioFinal2) 
    print("Gracias por tu Compra" , nombre)

else:
    print( "No tienes descuento")
    print(" Tu Precio final sin descuento es ", PrecioFinal) 
    print("Gracias por tu Compra" , nombre)

