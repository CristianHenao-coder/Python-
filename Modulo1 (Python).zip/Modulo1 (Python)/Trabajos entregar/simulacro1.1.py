
# 1. # Permitir al usuario agregar libros con atributos como: título, precio y cantidad disponible.
# Validar que el precio y la cantidad sean números positivos.

# 2. # Buscar un libro por su título y mostrar sus detalles (título, precio, cantidad).
# Si el libro no existe, mostrar un mensaje de error indicando que el libro no se encuentra en el inventario.

# 3. Modificar el precio de un libro específico en el inventario.
# Validar que el nuevo precio sea un número positivo antes de realizar el cambio.

# 4. 
# Permitir la eliminación de un libro que ya no está disponible.
# Confirmar la existencia del libro antes de eliminarlo

# 5. 
# Calcular el valor total del inventario multiplicando el precio por la cantidad de cada libro.
# Mostrar el total acumulado con dos decimales.


inventory = [
    {"title": "Book 1", "price": 10.0, "quantity": 100},
    {"title": "Book 2", "price": 15.0, "quantity": 50},
    {"title": "Book 3", "price": 20.0, "quantity": 30},
    {"title": "Book 4", "price": 25.0, "quantity": 10},
    {"title": "Book 5", "price": 30.0, "quantity": 5}]


def save_book():

    title= input("Ingrese el nombre del libro: ").lower()
    price= int(input("Ingresa el precio: "))
    quantity= int(input("Ingresa la cantidad de libros agregar: "))

    inventory.append({"title": title, "price": price,  "quantity": quantity})
        
    print(" se agrego correctamente" )


def search_book():
    name_book = str(input("Write the name of the book to search: "))
    
    for i in inventory:
        if name_book == i["title"]:
            print(f"\n\033[33m{i['title']}\033[0m price is: \033[32m${i["price"]}\033[0m and quantity is: \033[31m{i['quantity']}\033[0m")
            break
    else:
        print("Book is no in the list")

def update_book():
     namemodifi= input("Ingresa el nombre del libro que deseas actulizar el precio: ")
     for book in inventory:
        if book["title"]==namemodifi:
            newprice= int(input("Escriba su nuevo precio: "))
            book["price"]=newprice
            print("precio actulizado correctamente.")
        else:
            print("No encontrado el libro ")
def  eliminate_book():
    eliminbook= input("Escriba el nombre del Libro a Eliminar: ") 
    for book in inventory:
        if book["title"] == eliminbook: 
            inventory.remove(book)
            print("Libro eliminado")
           
    else:
        print("Libro no encontrado")    

        
print_table = lambda: print("\n".join(f"{i['title']} | {i['price']} | {i['quantity']}" for i in inventory) +
     f"\nTotal price inventory is \033[32m${sum(i['price'] * i['quantity'] for i in inventory)}\033[0m")

while True:

        print ("\033[01m\033[31m \n -------- MENÚ --------- \033[0m\n")
        print ("\033[01m Bienvenido Usuario \033[0m\n\n"  
            
        "1. Añadir libros al inventario:\n " \
        "2. Consultar libros en inventario:\n "
        "3. Actualizar precios de libros:\n "
        "4. Eliminar libros del inventario:\n "
        "5. Calcular el valor total del inventario:\n ")

        option = input(" Escribe una opción: ")

        match option:
            case  "1":
                save_book()
            case "2":
                search_book()
            case "3":
                update_book()
            case "4":
                eliminate_book()
            case "5":
                print(lambda)



    














